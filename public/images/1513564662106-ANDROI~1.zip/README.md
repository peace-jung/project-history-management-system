# Speace To Text for Android

## Android can connect to Node.js

## If you speak, send the text to Node.js Server
